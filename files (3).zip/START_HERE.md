# 🚀 START HERE - Quick Deployment Guide

## What You Have

A **complete, ready-to-deploy** Maajabu Restaurant website with:
- ✅ All bugs fixed (Liquid syntax errors resolved)
- ✅ GitHub Actions deployment configured
- ✅ SPA routing working
- ✅ Mobile responsive
- ✅ WhatsApp integration

**Package:** `maajabu-restaurant-COMPLETE.zip` (4.7 MB)

---

## Deploy in 3 Steps (5 minutes)

### Step 1: Create GitHub Repository
1. Go to https://github.com/new
2. Repository name: `maajabu-restaurant` (or any name)
3. Set to **Public**
4. **DO NOT** check any boxes (no README, no .gitignore, no license)
5. Click **"Create repository"**

### Step 2: Upload Files
1. **Extract** the `maajabu-restaurant-COMPLETE.zip` file
2. On the GitHub repository page, click **"uploading an existing file"**
3. **Drag and drop** the entire extracted folder contents
4. Scroll down and click **"Commit changes"**

### Step 3: Enable GitHub Pages
1. Click **"Settings"** (top right of repository)
2. Click **"Pages"** (left sidebar)
3. Under **"Source"**, select: **"GitHub Actions"**
4. That's it! No need to click Save or anything else

### Step 4: Wait & Access
1. Go to **"Actions"** tab (top of repository)
2. You'll see "Deploy to GitHub Pages" running
3. Wait for ✅ green checkmark (2-3 minutes)
4. Your site is now live at:
   ```
   https://YOUR-GITHUB-USERNAME.github.io/maajabu-restaurant/
   ```

---

## 📱 Test Your Site

After deployment, check:
- Homepage loads ✓
- Click "View Menu" ✓
- Click "About" ✓
- Click "Contact" ✓
- Try "Order on WhatsApp" button ✓

---

## 📚 Additional Resources

If you need more details:
- **DEPLOYMENT_CHECKLIST.md** - Complete checklist
- **DEPLOYMENT_GUIDE.md** - Detailed instructions with troubleshooting
- **README.md** - Project overview and local development

---

## ⚠️ Important Notes

### DO:
- ✅ Select "GitHub Actions" as source (not "Deploy from branch")
- ✅ Make repository Public (or use GitHub Pro for private)
- ✅ Upload ALL files from the extracted folder
- ✅ Wait for Actions workflow to complete

### DON'T:
- ❌ Don't select "Deploy from branch" in Pages settings
- ❌ Don't skip any files during upload
- ❌ Don't try to configure Jekyll (we're not using it)
- ❌ Don't panic if it takes a few minutes

---

## 🔧 Quick Customization

### Change WhatsApp Number
**File:** `src/pages/Contact.tsx`
```javascript
const WHATSAPP_NUMBER = "260971716370"; // Change this
const PHONE_NUMBER = "+260971716370";   // And this
```

### Update Menu Items
**File:** `src/data/menuData.ts`

### Change Restaurant Name
**File:** `index.html` and all `src/pages/*.tsx` files

---

## 🐛 Troubleshooting

### Problem: Blank page after deployment
**Solution:** Open browser console (F12), check for errors, verify base path in `vite.config.ts`

### Problem: Actions workflow fails
**Solution:** Go to Actions tab → Click the failed workflow → View error logs

### Problem: "Page build failed" message
**Solution:** You selected wrong source. Go to Settings → Pages → Change source to "GitHub Actions"

### Problem: 404 on /menu or /about
**Solution:** This should work automatically. Verify `public/404.html` exists in your uploaded files

---

## ✅ Success Indicators

You'll know it worked when:
1. ✅ Actions tab shows green checkmark
2. ✅ URL loads your restaurant homepage
3. ✅ Menu page shows food items
4. ✅ WhatsApp button opens chat with your number
5. ✅ Site works on mobile

---

## 🎉 You're Done!

That's it! Your restaurant website is now live on the internet.

**What's next?**
- Share the link with customers
- Test on different devices
- Customize the content
- Add your own images
- Update menu prices

---

## 📞 Quick Reference

- **WhatsApp:** Pre-configured to +260 971 716 370
- **Technologies:** React + Vite + TypeScript + Tailwind
- **Hosting:** GitHub Pages (Free!)
- **Deployment:** Automatic on every push to main

---

**Questions?** Check the other markdown files in this package for detailed info!

**Ready?** Start with Step 1 above! 🚀
